-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libime
Binary: libime-bin, libime-data, libime-data-language-model, libimecore-dev, libimecore0, libimepinyin-dev, libimepinyin0, libimetable-dev, libimetable0
Architecture: any all
Version: 1.1.17-1
Maintainer: Debian Input Method Team <debian-input-method@lists.debian.org>
Uploaders: Boyuan Yang <byang@debian.org>
Homepage: https://github.com/fcitx/libime
Description: Generic Input Method Implementation
 Libime is a generic input method implementation library. It is mainly
 used by fcitx5, the next generation of fcitx input method framework.
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/input-method-team/libime
Vcs-Git: https://salsa.debian.org/input-method-team/libime.git
Build-Depends: cmake (>= 3.12), debhelper-compat (= 13), extra-cmake-modules, libboost-dev (>= 1.61), libboost-iostreams-dev (>= 1.61), libdouble-conversion-dev (>= 3.1.5-5~), libfcitx5utils-dev (>= 5.1.20~), libzstd-dev, pkgconf
Package-List:
 libime-bin deb utils optional arch=any
 libime-data deb utils optional arch=all
 libime-data-language-model deb utils optional arch=any
 libimecore-dev deb libdevel optional arch=any
 libimecore0 deb libs optional arch=any
 libimepinyin-dev deb libdevel optional arch=any
 libimepinyin0 deb libs optional arch=any
 libimetable-dev deb libdevel optional arch=any
 libimetable0 deb libs optional arch=any
Checksums-Sha1:
 9e0948115d8dfe4db9e8baab325e21186cdb0d7b 85075832 libime_1.1.17.orig.tar.xz
 549f4178e777115fe8aa8912ca5f2ea7b6f169a2 9464 libime_1.1.17-1.debian.tar.xz
Checksums-Sha256:
 801ac1e12c0e7535fb29167cdf38f9482faeb3716f6df1fe90e4fe4204000308 85075832 libime_1.1.17.orig.tar.xz
 b871c85d9d073fe7c65a4120267448d948ef6b018b13ef524ab97d163b1c36e4 9464 libime_1.1.17-1.debian.tar.xz
Files:
 e740a17386017b4907805ffde064e144 85075832 libime_1.1.17.orig.tar.xz
 7e9d5b0e4a167b9e8ed216bcbee8951f 9464 libime_1.1.17-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEfncpR22H1vEdkazLwpPntGGCWs4FAmq1MrQACgkQwpPntGGC
Ws7qZQ//acjN6vIjqsQBktv+jOeoAQAe+GuLkjYxzJtDqYsnCAohSzGJa0SRDOgw
Vq/fJp3UL9sXK5Vydq4tukeJCEffP1rGyANDQolIrHhdpaDqtsu/jWYakmWLKMRj
qDGbe/OpwE7oqFphIMG8nZqopG1bee1qA08PQdng4lv5dt/0IzqKxFasyvI3eD8z
UgrnUKqz7Ppr7W0q/TNaWlsTTw8OyiKT76PC7TCO5OPl3DBdS2z3aP3/nIbYM/m2
I7dZPwRl5NVqsUYD+L8xLSvqT3xQ1gz2hkQAjF++K/Wza/0cmBniIKNC5qh9VWWV
PjLZNHRKcJ/QOodl/iRS+nndli1WYf73VjD3Um2bC+rr0POaww8MbLQpHWpsJ9RO
W940GC7WcCWXDEBwiMln24GwQV/9hhmS9ZgzwZTdi02TbCCl3CUFQqq0JUHTixug
dZZEqoqTP9hhR72y6D0RXjVqF+7gWLQ16QcCdjmqb13j6nnJctmPEl2FPxRWGm4l
fW7JD/6GO0xDXPz29Ww4fTASTBjBOF19m/G5hvw/q+fqAYeuNlLsuVPOwjFGcE0d
db0GjUPZacEvWcraq34ji0jsGel2GmD5H7NrgkpuzWaMK4EMB9wescicOAAg3WGv
RGf8P9RewNaREQWKSAavkTMMxCBWQL4Il9szAC20sfOVwvvz/rA=
=7I/+
-----END PGP SIGNATURE-----
