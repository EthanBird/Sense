package io.github.ethanbird.senseime.core

/** Immutable, opt-in binding. A missing model/zero weight uses the original decoder exactly. */
internal data class PinyinLanguageBinding(
    val model: CharacterLanguageModel,
    val weight: Float,
    val correctionCompositionBoost: Float = 12f,
)

/**
 * Query-local log-linear feature, NOT a normalized sentence probability. Character emissions
 * are counted once, independent of word boundaries; no EOS is added to an unfinished editor.
 * All spellings for this raw query share one positive score normalizer (six letters/word).
 * +6 is an explicit character insertion prior; clipping/OOV neutrality bound corpus bias.
 */
internal class PinyinLanguageScorer(
    private val binding: PinyinLanguageBinding,
    rawQuery: String,
    val initialState: Long,
) {
    val normalizer = maxOf(1f, rawQuery.length / 6f)
    data class Step(val state: Long, val score: Float)
    private data class Edge(val state: Long, val text: String)
    private val cache = HashMap<Edge, Step>()

    fun extend(state: Long, text: String): Step {
        val key = Edge(state, text)
        cache[key]?.let { return it }
        var previous2 = (state ushr 21).toInt()
        var previous1 = (state and MASK).toInt()
        var score = 0f
        var offset = 0
        while (offset < text.length) {
            val next = text.codePointAt(offset)
            offset += Character.charCount(next)
            if (Character.UnicodeScript.of(next) != Character.UnicodeScript.HAN) {
                previous2 = CharacterLanguageModel.BOS
                previous1 = CharacterLanguageModel.BOS
                continue
            }
            if (binding.model.containsCodePoint(next)) {
                val logProbability = binding.model.logProbability(previous2, previous1, next)
                if (logProbability.isFinite()) score += (logProbability + 6f).coerceIn(-6f, 6f)
            }
            previous2 = previous1
            previous1 = next
        }
        val result = Step(pack(previous2, previous1), score * binding.weight)
        // Never retain editor text beyond one decode; cap even adversarial correction lattices.
        if (cache.size < 4_096) cache[key] = result
        return result
    }

    fun feature(text: String): Float = extend(initialState, text).score / normalizer
    /**
     * A syntactically valid word path is weaker evidence than an exact dictionary word.
     * In the LM score domain the old composed-vs-corrected prior gap was 14 points,
     * dwarfing contextual evidence even for nonsensical literal parses. Preserve a
     * 2-point typed prior, in addition to the unchanged spelling edit penalty.
     * Stored once in Candidate.score so personalization/mixed ranking never adds it twice.
     */
    fun sourceAdjustment(kind: CandidateMatchKind, exact: Boolean, composed: Boolean): Float =
        if (kind == CandidateMatchKind.CORRECTED && !exact && composed) binding.correctionCompositionBoost else 0f
    fun lexical(score: Float, logMass: Float): Float = logMass + (score - logMass) / normalizer

    companion object {
        private const val MASK = 0x1FFFFFL
        fun pack(previous2: Int, previous1: Int): Long = (previous2.toLong() shl 21) or previous1.toLong()
        fun context(text: CharSequence): Long {
            if (text.isEmpty()) return context(-1)
            val last = Character.codePointBefore(text, text.length)
            if (Character.UnicodeScript.of(last) != Character.UnicodeScript.HAN) return context(-1)
            val offset = text.length - Character.charCount(last)
            val previous = if (offset > 0) Character.codePointBefore(text, offset) else -1
            return pack(if (Character.isValidCodePoint(previous) && Character.UnicodeScript.of(previous) == Character.UnicodeScript.HAN)
                previous else CharacterLanguageModel.BOS, last)
        }
        fun context(previousCodePoint: Int): Long = pack(CharacterLanguageModel.BOS,
            if (Character.isValidCodePoint(previousCodePoint) && Character.UnicodeScript.of(previousCodePoint) == Character.UnicodeScript.HAN)
                previousCodePoint else CharacterLanguageModel.BOS)
    }
}
